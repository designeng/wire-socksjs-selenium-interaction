define(function() {
  var RegisterTemplateController;
  return RegisterTemplateController = (function() {
    function RegisterTemplateController() {}

    RegisterTemplateController.prototype.registerTemplateContent = function(html) {
      return console.log("registerTemplateContent::::::::::::::", this.prospectViewTemplatesCollection);
    };

    return RegisterTemplateController;

  })();
});
