define({
  $plugins: [],
  mainFunc: function() {
    return alert("main context func");
  }
});
