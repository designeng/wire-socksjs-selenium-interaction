define({
  ru: true,
  de: true,
  es: true,
  lv: true,
  root: {
    firstName: "Name",
    lastName: "Last Name",
    dateOfBirth: "Date of Birth",
    citizenship: "Citizenship",
    documentNumber: "Document Number",
    validity: "Validity",
    chooseDate: "choose date",
    loyaltyCardAirlines: "Loyalty Card Airlines",
    save: "Save"
  }
});
