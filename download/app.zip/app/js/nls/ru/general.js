define({
  firstName: "Имя",
  lastName: "Фамилия",
  dateOfBirth: "Дата рождения",
  citizenship: "Гражданство",
  documentNumber: "Номер документа",
  validity: "Срок действия",
  chooseDate: "выбрать дату",
  loyaltyCardAirlines: "Бонусная карта авиакомпании",
  save: "Сохранить"
});
